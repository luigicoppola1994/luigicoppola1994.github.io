// Funzione per eseguire operazioni matematiche
function calcola(operatore) {
    // Ottieni i valori inseriti dall'utente e convertili in interi
    var numero1 = parseInt(document.getElementById('numero1').value);
    var numero2 = parseInt(document.getElementById('numero2').value);

    // Controlla se i valori inseriti sono numeri validi (interi)
    if (isNaN(numero1) || isNaN(numero2)) {
        // Mostra un alert se i valori non sono numeri interi
        alert("Inserisci numeri interi validi");
        return; // Esce dalla funzione
    }

    // Effettua l'operazione richiesta
    var risultato;
    switch (operatore) {
        case '+':
            risultato = numero1 + numero2;
            break;
        case '-':
            risultato = numero1 - numero2;
            break;
        case '*':
            risultato = numero1 * numero2;
            break;
        case '/':
            // Controlla se il secondo numero è zero
            if (numero2 === 0) {
                // Mostra un alert se si sta cercando di dividere per zero
                alert("Impossibile dividere per zero");
                return; // Esce dalla funzione
            }
            risultato = numero1 / numero2;
            break;
        default:
            // Mostra un alert se l'operatore non è valido
            alert("Operatore non valido");
            return; // Esce dalla funzione
    }

    // Mostra il risultato
    document.getElementById('risultato').innerText = "Il risultato è: " + risultato;
}

// Funzione per azzerare i valori
function reset() {
    // Resetta i valori degli input e del risultato
    document.getElementById('numero1').value = "";
    document.getElementById('numero2').value = "";
    document.getElementById('risultato').innerText = "Il risultato apparirà qui";
}
